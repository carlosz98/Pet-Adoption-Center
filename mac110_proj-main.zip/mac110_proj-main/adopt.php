<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = filter_var(trim($_POST["name"]), FILTER_SANITIZE_STRING);
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $message = filter_var(trim($_POST["message"]), FILTER_SANITIZE_STRING);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format";
        exit;
    }

    // Here you can send the email or save the message to your database
    // For demonstration, we'll just echo a success message
    echo "Thank you, $name! Your inquiry has been received.";
    // Optionally, send an email
    // mail($to, $subject, $message, $headers);
}
?>

