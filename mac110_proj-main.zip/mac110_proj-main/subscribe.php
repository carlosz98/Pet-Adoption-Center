<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format";
        exit;
    }

    // Here you can add the email to your database or send a confirmation email
    // For demonstration, we'll just echo a success message
    echo "Thank you for subscribing! We will keep you updated at $email.";
}
?>
