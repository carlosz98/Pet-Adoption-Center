document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("newsletter-form");
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        const emailInput = document.getElementById("email");
        alert(`Thank you for subscribing with ${emailInput.value}!`);
        emailInput.value = ''; // Clear the input
    });
});

//about page script 

document.addEventListener("DOMContentLoaded", () => {
    const contactForm = document.getElementById("contact-form");
    contactForm.addEventListener("submit", (e) => {
        e.preventDefault();
        alert(`Thank you for your message, ${document.getElementById("name").value}!`);
        contactForm.reset(); // Clear the form
    });
});

//adopt page script

document.addEventListener("DOMContentLoaded", () => {
    const adoptionForm = document.getElementById("adoption-form");
    adoptionForm.addEventListener("submit", (e) => {
        e.preventDefault();
        alert(`Thank you for your inquiry, ${document.getElementById("name").value}! We will get back to you shortly.`);
        adoptionForm.reset(); // Clear the form
    });
});

//foster page script 

document.addEventListener("DOMContentLoaded", () => {
    const fosterForm = document.getElementById("foster-form");
    fosterForm.addEventListener("submit", (e) => {
        e.preventDefault();
        alert(`Thank you for your application, ${document.getElementById("name").value}! We will review it shortly.`);
        fosterForm.reset(); // Clear the form
    });
});
//volunteer page script 
document.addEventListener("DOMContentLoaded", () => {
    const volunteerForm = document.getElementById("volunteer-form");
    volunteerForm.addEventListener("submit", (e) => {
        e.preventDefault();
        alert(`Thank you for your application, ${document.getElementById("name").value}! We will review it shortly.`);
        volunteerForm.reset(); // Clear the form
    });
});

